create table users
(
	uid varchar(11) primary key,
	name varchar(20),
	msg varchar(300),
	type varchar(3)
);