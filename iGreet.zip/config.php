<?php
define("DB_NAME","dpro8742_ogs");
define("DB_USER","dpro8742_igreet");
define("DB_PASS","Sidharth12");
define("DB_HOST","localhost");
?>
